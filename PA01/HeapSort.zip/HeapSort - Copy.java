// acknowledge the folder that HeapSort.java resides in
package PA01;

// create our HeapSort class
public class HeapSort {

    // define the main functionality
    public static void main(String[] args) {
        int[] A = {3, 17, 12, 41, 18, 2, 5};
        int order = 0;
        int n = A.length;

        BuildHeap(A, n, order);

        for (int i = n - 1; i >= 1; i--) {
            int temp = A[i];
            A[i] = A[0];
            A[0] = temp;

            MaxHeapify(A, 0, i, order);
        }

        printArray(A);

    }

    // define our BuildMaxHeap and MaxHeapify functions
    public static void BuildHeap(int[] A, int n, int order) {
        for (int i = Math.floorDiv(n, 2); i >= 0; i--) {
            MaxHeapify(A, i, n, order);
        }
    }

    public static void MaxHeapify(int[] A, int i, int n, int order) {
        int l = 2*i + 1;
        int r = 2*i + 2;
        int extreme = i;

        if (order == 0) {
            if (l < n && A[l] > A[i]) {
                extreme = l;
            } else {
                extreme = i;
            }

            if (r < n && A[r] > A[extreme]) {
                extreme = r;
            }

            if (extreme != i) {
                int temp = A[i];
                A[i] = A[extreme];
                A[extreme] = temp;
                MaxHeapify(A, extreme, n, order);
            }
        } else {
            if (l < n && A[l] < A[i]) {
                extreme = l;
            } else {
                extreme = i;
            }

            if (r < n && A[r] < A[extreme]) {
                extreme = r;
            }

            if (extreme != i) {
                int temp = A[i];
                A[i] = A[extreme];
                A[extreme] = temp;
                MaxHeapify(A, extreme, n, order);
            }
        }
    }

    public static void printArray(int[] A) {
        for (int val : A) System.out.print(val + " ");
        System.out.println();
    }
}